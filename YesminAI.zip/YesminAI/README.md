# Yesmin AI

A native Android app (Kotlin, Jetpack Compose, Material 3) with:

- **AI chat** using the Google Gemini API
- **Voice**: mic button (Android `SpeechRecognizer`) and spoken replies (`TextToSpeech`)
- **Open apps**: "open YouTube", "open Settings", ...
- **WhatsApp drafts**: opens WhatsApp with your message typed in. You press Send.
- **Optional accessibility service**: Back, Home, Recents, notifications, quick settings, lock screen, screenshot, only when you ask. Off until you enable it.
- **Settings** for the AI, speech, WhatsApp and permissions, each explained in the app.

Package `com.yesmin.ai` · min SDK 26 (Android 8.0) · target/compile SDK 35 · AGP 8.7.3 · Kotlin 2.0.21 · Gradle 8.9 · Compose BOM 2024.12.01.

---

## Build the APK from your phone (no computer)

You need a free GitHub account and a mobile browser. Desktop-site mode helps.

### 1. Create the repository
1. In GitHub, tap **+ → New repository**. Name it `YesminAI`. Private is fine. Create it.

### 2. Upload the project
You have two ways. **Way A is easiest on a phone.**

**Way A, upload the zip as it is (no unzipping):**
1. In the repo tap **Add file → Upload files**.
2. Choose **YesminAI.zip** and tap **Commit changes**.
3. Tap **Add file → Create new file**. In the name box type exactly
   `.github/workflows/android.yml`
   (typing the `/` creates the folders).
4. Open the separate `android.yml` file you were given, copy everything, paste it into the editor, and tap **Commit changes**.

The workflow notices the zip, unpacks it and builds it.

**Way B, upload the unzipped files:** unzip on your phone, then upload every file and folder (including the hidden `.github` folder) keeping the same layout. This is fiddly on mobile; use Way A if you can.

### 3. Run the build
- Committing the workflow file starts a build automatically.
- Or open the **Actions** tab → **Android Debug APK** → **Run workflow**.
- The first build takes roughly 5 to 10 minutes.

### 4. Download and install
1. Open the finished run (green tick) and scroll to **Artifacts**.
2. Tap **YesminAI-debug-apk**. You get a zip; open it in your Files app to extract `app-debug.apk`.
3. Tap the APK and allow **Install unknown apps** for your browser or Files app when asked.

### If the build fails
Open the failed run, open the red step, and copy the first lines that contain `error:` or `What went wrong`. Send them to me and I'll fix the project.

---

## Add your Gemini API key

Get a key at <https://aistudio.google.com/apikey>.

**Recommended:** open the app → ⚙ Settings → paste the key → **Save key** → **Test connection**. It is stored encrypted with the Android Keystore on your phone only.

**Optional build-time key:** add a repository secret named `GEMINI_API_KEY` (Settings → Secrets and variables → Actions). The workflow passes it to the build. Be aware that a key built into an APK can be extracted by anyone who gets the APK, so use this only for an APK you never share. A key saved in the app always overrides the built-in one. No real key is ever stored in the source code.

If chat says the model was not found, change the **Model** in Settings (default `gemini-2.5-flash`) to a current Gemini model name.

---

## Using it

| You say or type | What happens |
|---|---|
| Any question | Gemini answers |
| `open YouTube`, `open Settings`, `open camera` | The app is launched with a normal Android intent |
| `send WhatsApp to +91 98765 43210 saying hello` | WhatsApp opens on that chat with the text filled in |
| `send WhatsApp message hello` | WhatsApp opens its contact picker with the text filled in |
| top-bar chat button | Form to prepare a WhatsApp draft |
| `go back`, `go home`, `recent apps`, `show notifications`, `quick settings`, `lock screen`, `take a screenshot` | Needs the accessibility service (below) |
| `help` | Lists the commands |

Tap the mic to speak, tap it again to stop. Replies are read aloud unless you turn that off in Settings.

---

## Permissions and honest limits

| Feature | Permission | Notes |
|---|---|---|
| Chat | Internet (automatic) | Your messages go to Google's Gemini API |
| Voice input | Microphone, asked when you tap the mic | Needs a speech service (usually the Google app). Some services need internet. The app explains when recognition is unavailable or permission is blocked |
| Spoken replies | none | Needs a text-to-speech engine and voice data for your language |
| Open apps | none | Only apps Android lets this app see (a `<queries>` entry declares the launcher intent; no `QUERY_ALL_PACKAGES`) |
| WhatsApp | none | Never sends. No contacts permission. Needs WhatsApp or WhatsApp Business installed |
| Accessibility | You enable it manually | See below |

### The accessibility service
- It stays **off** until you enable it in Android Settings → Accessibility.
- It is configured with **no event subscription**, `canRetrieveWindowContent=false` and `canPerformGestures=false`. It cannot read your screen, see what you type, read passwords, or tap for you.
- All it can do is trigger Android's global actions (Back, Home, Recents, notifications, quick settings, lock screen, screenshot) after you ask. Lock screen and screenshot need Android 9+.
- **Android 13 and newer block this for apps installed outside the Play Store** until you allow it: Android Settings → Apps → Yesmin AI → ⋮ menu → **Allow restricted settings**. Then enable the service.
- This app does **not** try to automate other apps, press buttons inside them or read their content.

### Other limits
- Debug APKs are signed with a debug key. Fine for personal use, not for the Play Store.
- Chat history is kept in memory only and is cleared when the app is closed.
- The system prompt tells Gemini it cannot control the phone itself, so it won't pretend to.

---

## Project layout

```
.github/workflows/android.yml        CI: builds the debug APK and uploads it
settings.gradle.kts, build.gradle.kts, gradle/libs.versions.toml
app/build.gradle.kts
app/src/main/AndroidManifest.xml
app/src/main/res/...                 icons, themes, accessibility config
app/src/main/java/com/yesmin/ai/
  MainActivity.kt
  ai/GeminiClient.kt                 REST client with clear error messages
  data/SettingsRepository.kt, SecureStore.kt   settings + Keystore-encrypted API key
  voice/SpeechInput.kt, Speaker.kt   SpeechRecognizer and TextToSpeech wrappers
  actions/AppLauncher.kt, WhatsAppHelper.kt, CommandRouter.kt
  accessibility/YesminAccessibilityService.kt
  ui/ChatScreen.kt, SettingsScreen.kt, ChatViewModel.kt, theme/Theme.kt
```

## Building on a computer (optional)
Open the folder in Android Studio (Ladybug or newer) and press Run, or run `./gradlew assembleDebug`. The APK is at `app/build/outputs/apk/debug/app-debug.apk`. To embed a key locally add `GEMINI_API_KEY=...` to `local.properties` (it is git-ignored).
