import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

/**
 * Optional build-time Gemini key, read from (in order):
 *  1. the GEMINI_API_KEY environment variable (e.g. a GitHub Actions secret)
 *  2. GEMINI_API_KEY in local.properties (never committed, see .gitignore)
 * If neither exists the app builds with an empty key and the user enters one in Settings.
 * NOTE: a key baked in at build time can be extracted from the APK. Prefer entering the key in-app.
 */
fun readBuildTimeGeminiKey(): String {
    val fromEnv = System.getenv("GEMINI_API_KEY")
    if (!fromEnv.isNullOrBlank()) return fromEnv.trim()
    val localFile = rootProject.file("local.properties")
    if (localFile.exists()) {
        val props = Properties()
        localFile.inputStream().use { props.load(it) }
        val fromFile = props.getProperty("GEMINI_API_KEY")
        if (!fromFile.isNullOrBlank()) return fromFile.trim()
    }
    return ""
}

android {
    namespace = "com.yesmin.ai"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.yesmin.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        val escapedKey = readBuildTimeGeminiKey().replace("\\", "\\\\").replace("\"", "\\\"")
        buildConfigField("String", "GEMINI_API_KEY", "\"$escapedKey\"")
        buildConfigField("String", "DEFAULT_GEMINI_MODEL", "\"gemini-2.5-flash\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.activity.compose)
    implementation(libs.kotlinx.coroutines.android)

    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.material.icons.core)

    debugImplementation(libs.androidx.compose.ui.tooling)
}
