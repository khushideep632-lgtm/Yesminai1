package com.yesmin.ai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.speech.SpeechRecognizer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LifecycleResumeEffect
import com.yesmin.ai.BuildConfig
import com.yesmin.ai.accessibility.YesminAccessibilityService
import com.yesmin.ai.ai.GeminiClient
import com.yesmin.ai.data.KeySource
import com.yesmin.ai.data.SecureStore
import com.yesmin.ai.data.SettingsRepository
import com.yesmin.ai.model.ChatMessage
import com.yesmin.ai.model.Role
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val settings = vm.settings
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            AiSection(settings)
            SpeechSection(settings, vm)
            WhatsAppSection(settings)
            PermissionsSection()
            AboutSection()
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

// ---------------------------------------------------------------- AI configuration

@Composable
private fun AiSection(settings: SettingsRepository) {
    val scope = rememberCoroutineScope()
    val uriHandler = LocalUriHandler.current

    var keyInput by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var keySource by remember { mutableStateOf(settings.keySource()) }
    var keyMessage by remember { mutableStateOf<String?>(null) }

    var model by remember { mutableStateOf(settings.model) }
    var systemPrompt by remember { mutableStateOf(settings.systemPrompt) }
    var temperature by remember { mutableFloatStateOf(settings.temperature) }

    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }

    SectionCard("AI configuration") {
        Text(
            when (keySource) {
                KeySource.USER_SAVED -> "API key: saved on this device (encrypted with the Android Keystore)."
                KeySource.BUILD_TIME -> "API key: built into this APK at build time. You can override it below."
                KeySource.NONE -> "API key: not set. AI chat is disabled until you add one."
            },
            style = MaterialTheme.typography.bodyMedium,
        )
        OutlinedTextField(
            value = keyInput,
            onValueChange = { keyInput = it; keyMessage = null },
            label = { Text("Gemini API key") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = showKey, onCheckedChange = { showKey = it })
            Text("  Show key while typing", style = MaterialTheme.typography.bodyMedium)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = keyInput.isNotBlank(),
                onClick = {
                    keyMessage = try {
                        settings.saveUserApiKey(keyInput)
                        keyInput = ""
                        keySource = settings.keySource()
                        "Key saved."
                    } catch (e: SecureStore.SecureStoreException) {
                        e.message
                    }
                },
            ) { Text("Save key") }
            OutlinedButton(
                enabled = keySource == KeySource.USER_SAVED,
                onClick = {
                    settings.clearUserApiKey()
                    keySource = settings.keySource()
                    keyMessage = "Saved key removed."
                },
            ) { Text("Remove saved key") }
        }
        keyMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        TextButton(onClick = {
            try {
                uriHandler.openUri("https://aistudio.google.com/apikey")
            } catch (e: Exception) {
                keyMessage = "No browser found. Visit aistudio.google.com/apikey to create a key."
            }
        }) { Text("Get a Gemini API key (opens browser)") }

        HorizontalDivider()

        OutlinedTextField(
            value = model,
            onValueChange = { model = it; settings.model = it },
            label = { Text("Model") },
            supportingText = { Text("Default: ${BuildConfig.DEFAULT_GEMINI_MODEL}") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = systemPrompt,
            onValueChange = { systemPrompt = it; settings.systemPrompt = it },
            label = { Text("Assistant instructions") },
            minLines = 3,
            maxLines = 8,
            modifier = Modifier.fillMaxWidth(),
        )
        TextButton(onClick = {
            systemPrompt = SettingsRepository.DEFAULT_SYSTEM_PROMPT
            settings.systemPrompt = systemPrompt
        }) { Text("Reset instructions to default") }
        Text("Creativity (temperature): ${"%.1f".format(temperature)}", style = MaterialTheme.typography.bodyMedium)
        Slider(
            value = temperature,
            onValueChange = { temperature = it; settings.temperature = it },
            valueRange = 0f..2f,
        )

        Button(
            enabled = !testing,
            onClick = {
                scope.launch {
                    testing = true
                    testResult = null
                    val result = GeminiClient.generate(
                        apiKey = settings.apiKey(),
                        model = settings.model,
                        systemPrompt = "",
                        temperature = 0f,
                        history = listOf(ChatMessage(0, Role.USER, "Reply with the single word: OK")),
                    )
                    testResult = result.fold(
                        onSuccess = { "Connection works. The model replied: ${it.take(60)}" },
                        onFailure = { it.message ?: "Unknown error" },
                    )
                    testing = false
                }
            },
        ) { Text(if (testing) "Testing…" else "Test connection") }
        testResult?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

// ---------------------------------------------------------------- Speech

@Composable
private fun SpeechSection(settings: SettingsRepository, vm: ChatViewModel) {
    val context = LocalContext.current
    var speak by remember { mutableStateOf(settings.speakReplies) }
    var language by remember { mutableStateOf(settings.speechLanguage) }
    var rate by remember { mutableFloatStateOf(settings.speechRate) }
    var testMessage by remember { mutableStateOf<String?>(null) }
    var recognitionAvailable by remember { mutableStateOf(SpeechRecognizer.isRecognitionAvailable(context)) }

    LifecycleResumeEffect(Unit) {
        recognitionAvailable = SpeechRecognizer.isRecognitionAvailable(context)
        onPauseOrDispose { }
    }

    SectionCard("Speech") {
        Text(
            if (recognitionAvailable) "Speech recognition (microphone button): available."
            else "Speech recognition: not available on this device. Install or enable a speech service " +
                "(for example the Google app) in Android Settings. Typing still works.",
            style = MaterialTheme.typography.bodyMedium,
        )
        Text(
            when {
                vm.speaker.initFailed ->
                    "Text-to-speech: no engine found. Install one in Android Settings > Text-to-speech."
                vm.speaker.isReady -> "Text-to-speech (spoken replies): ready."
                else -> "Text-to-speech: starting…"
            },
            style = MaterialTheme.typography.bodyMedium,
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = speak, onCheckedChange = { speak = it; settings.speakReplies = it })
            Text("  Speak replies aloud", style = MaterialTheme.typography.bodyMedium)
        }
        OutlinedTextField(
            value = language,
            onValueChange = { language = it; settings.speechLanguage = it },
            label = { Text("Speech language (optional)") },
            supportingText = { Text("For example en-US or hi-IN. Leave blank to use the device language.") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Text("Voice speed: ${"%.1f".format(rate)}x", style = MaterialTheme.typography.bodyMedium)
        Slider(
            value = rate,
            onValueChange = { rate = it; settings.speechRate = it },
            valueRange = 0.5f..2f,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { testMessage = vm.speakTest() }) { Text("Test voice") }
            TextButton(onClick = {
                try {
                    context.startActivity(
                        Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    testMessage = "Open Android Settings and search for \"Text-to-speech\"."
                }
            }) { Text("Voice settings") }
        }
        testMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

// ---------------------------------------------------------------- WhatsApp

@Composable
private fun WhatsAppSection(settings: SettingsRepository) {
    var countryCode by remember { mutableStateOf(settings.defaultCountryCode) }
    SectionCard("WhatsApp") {
        Text(
            "Yesmin can open WhatsApp with a message already typed. It never sends it: you review " +
                "the draft and tap Send yourself. No contacts permission is needed; to pick a " +
                "recipient, enter a number or choose a contact inside WhatsApp.",
            style = MaterialTheme.typography.bodyMedium,
        )
        OutlinedTextField(
            value = countryCode,
            onValueChange = { countryCode = it.filter { c -> c.isDigit() }; settings.defaultCountryCode = countryCode },
            label = { Text("Default country code (optional)") },
            supportingText = { Text("Digits only, e.g. 91. Used for numbers typed without a + prefix.") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

// ---------------------------------------------------------------- Permissions

@Composable
private fun PermissionsSection() {
    val context = LocalContext.current
    var micGranted by remember { mutableStateOf(hasMic(context)) }
    var a11yEnabled by remember { mutableStateOf(YesminAccessibilityService.isEnabledInSettings(context)) }

    LifecycleResumeEffect(Unit) {
        micGranted = hasMic(context)
        a11yEnabled = YesminAccessibilityService.isEnabledInSettings(context)
        onPauseOrDispose { }
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        micGranted = granted
        if (!granted) {
            val activity = context.findActivity()
            val canAskAgain = activity != null &&
                ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.RECORD_AUDIO)
            if (!canAskAgain) context.openAppDetailsSettings()
        }
    }

    SectionCard("Permissions and what they are for") {
        PermissionRow(
            name = "Microphone",
            status = if (micGranted) "Allowed" else "Not allowed",
            description = "Needed only for the mic button (voice input). Without it you can still type.",
        ) {
            if (micGranted) {
                TextButton(onClick = { context.openAppDetailsSettings() }) { Text("Manage in Android settings") }
            } else {
                Button(onClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }) { Text("Allow microphone") }
            }
        }
        HorizontalDivider()
        PermissionRow(
            name = "Internet",
            status = "Granted at install",
            description = "Needed to reach the Gemini API. Android doesn't ask for this one.",
        )
        HorizontalDivider()
        PermissionRow(
            name = "Opening apps",
            status = "No permission needed",
            description = "\"Open <app>\" uses standard launcher intents and can only open apps Android " +
                "lets this app see. It cannot bypass Android's security rules.",
        )
        HorizontalDivider()
        PermissionRow(
            name = "Accessibility service (optional)",
            status = if (a11yEnabled) "Enabled" else "Off",
            description = "Off by default. If you turn it on, Yesmin can press Back, Home or Recents, open " +
                "notifications or quick settings, lock the screen, or take a screenshot, and only when you " +
                "ask. It is configured so it cannot read your screen, see what you type, read passwords, " +
                "or tap for you. You can switch it off any time in Android Settings.",
        ) {
            Button(onClick = {
                try {
                    context.startActivity(
                        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    // Settings screen unavailable; the hint below still explains the path.
                }
            }) { Text(if (a11yEnabled) "Manage in Accessibility settings" else "Open Accessibility settings") }
            Text(
                "Steps: Accessibility > Installed apps (or Downloaded apps) > Yesmin AI actions > turn on. " +
                    "On Android 13 and newer, an app installed outside the Play Store is blocked from this " +
                    "until you open Android Settings > Apps > Yesmin AI, tap the ⋮ menu and choose " +
                    "\"Allow restricted settings\".",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        HorizontalDivider()
        PermissionRow(
            name = "Contacts, SMS, notifications, files",
            status = "Not requested",
            description = "Yesmin does not ask for these.",
        )
    }
}

@Composable
private fun PermissionRow(
    name: String,
    status: String,
    description: String,
    actions: @Composable ColumnScope.() -> Unit = {},
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
            Text(status, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        }
        Text(description, style = MaterialTheme.typography.bodySmall)
        actions()
    }
}

private fun hasMic(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

// ---------------------------------------------------------------- About

@Composable
private fun AboutSection() {
    SectionCard("About Yesmin AI") {
        Text("Version ${BuildConfig.VERSION_NAME}", style = MaterialTheme.typography.bodyMedium)
        Text(
            "Your messages are sent to Google's Gemini API to generate answers. Your API key stays on " +
                "this device. Yesmin keeps no server of its own and collects no analytics.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
