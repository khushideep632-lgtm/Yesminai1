package com.yesmin.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.yesmin.ai.ui.ChatScreen
import com.yesmin.ai.ui.ChatViewModel
import com.yesmin.ai.ui.SettingsScreen
import com.yesmin.ai.ui.theme.YesminTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            YesminTheme {
                YesminRoot()
            }
        }
    }
}

@Composable
private fun YesminRoot() {
    val vm: ChatViewModel = viewModel()
    var showSettings by rememberSaveable { mutableStateOf(false) }

    // Re-check the API key whenever we come back from Settings.
    LaunchedEffect(showSettings) { if (!showSettings) vm.refreshConfig() }

    if (showSettings) {
        BackHandler { showSettings = false }
        SettingsScreen(vm = vm, onBack = { showSettings = false })
    } else {
        ChatScreen(vm = vm, onOpenSettings = { showSettings = true })
    }
}
