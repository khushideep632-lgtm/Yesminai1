package com.yesmin.ai.ai

import com.yesmin.ai.model.ChatMessage
import com.yesmin.ai.model.Role
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.SSLException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class GeminiException(message: String, val kind: Kind) : Exception(message) {
    enum class Kind { NO_KEY, BAD_MODEL, NETWORK, AUTH, NOT_FOUND, QUOTA, BLOCKED, SERVER, BAD_RESPONSE }
}

/**
 * Minimal Gemini REST client (generateContent) built on HttpURLConnection and org.json,
 * so no extra dependencies are needed. The API key is sent in the x-goog-api-key header,
 * never in the URL, so it does not end up in logs or proxies' URL records.
 */
object GeminiClient {

    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/"
    private const val MAX_HISTORY_MESSAGES = 20
    private val MODEL_PATTERN = Regex("^[A-Za-z0-9._-]+$")

    suspend fun generate(
        apiKey: String,
        model: String,
        systemPrompt: String,
        temperature: Float,
        history: List<ChatMessage>,
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            Result.success(request(apiKey, model, systemPrompt, temperature, history))
        } catch (e: CancellationException) {
            throw e
        } catch (e: GeminiException) {
            Result.failure(e)
        } catch (e: UnknownHostException) {
            Result.failure(
                GeminiException(
                    "Can't reach the Gemini service. Check that your phone is online.",
                    GeminiException.Kind.NETWORK
                )
            )
        } catch (e: SocketTimeoutException) {
            Result.failure(
                GeminiException(
                    "The request timed out. Check your connection and try again.",
                    GeminiException.Kind.NETWORK
                )
            )
        } catch (e: SSLException) {
            Result.failure(
                GeminiException(
                    "A secure connection to Gemini could not be established. Check your date/time and network.",
                    GeminiException.Kind.NETWORK
                )
            )
        } catch (e: IOException) {
            Result.failure(
                GeminiException(
                    "Network error: ${e.message ?: "connection failed"}.",
                    GeminiException.Kind.NETWORK
                )
            )
        } catch (e: JSONException) {
            Result.failure(
                GeminiException(
                    "Gemini returned a response the app could not read.",
                    GeminiException.Kind.BAD_RESPONSE
                )
            )
        }
    }

    private fun request(
        apiKey: String,
        model: String,
        systemPrompt: String,
        temperature: Float,
        history: List<ChatMessage>,
    ): String {
        if (apiKey.isBlank()) {
            throw GeminiException(
                "No Gemini API key is set. Open Settings and add your key.",
                GeminiException.Kind.NO_KEY
            )
        }
        val modelId = model.trim().removePrefix("models/")
        if (!MODEL_PATTERN.matches(modelId)) {
            throw GeminiException(
                "The model name \"$model\" looks invalid. Fix it in Settings (for example gemini-2.5-flash).",
                GeminiException.Kind.BAD_MODEL
            )
        }

        val body = buildBody(systemPrompt, temperature, history).toString()
        val connection = URL("$BASE_URL$modelId:generateContent").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 15_000
            connection.readTimeout = 60_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("x-goog-api-key", apiKey)
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw httpError(code, text)
            return parseReply(text)
        } finally {
            connection.disconnect()
        }
    }

    private fun buildBody(
        systemPrompt: String,
        temperature: Float,
        history: List<ChatMessage>,
    ): JSONObject {
        // Gemini expects the conversation to start with a user turn; skip error bubbles.
        val turns = history
            .filter { !it.isError }
            .takeLast(MAX_HISTORY_MESSAGES)
            .dropWhile { it.role != Role.USER }

        val contents = JSONArray()
        for (m in turns) {
            contents.put(
                JSONObject()
                    .put("role", if (m.role == Role.USER) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
            )
        }

        val body = JSONObject().put("contents", contents)
        if (systemPrompt.isNotBlank()) {
            body.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
        }
        body.put(
            "generationConfig",
            JSONObject().put("temperature", temperature.toDouble().coerceIn(0.0, 2.0))
        )
        return body
    }

    private fun parseReply(json: String): String {
        val root = JSONObject(json)
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            if (reason.isNotBlank()) {
                throw GeminiException(
                    "Gemini blocked this request ($reason). Try rephrasing it.",
                    GeminiException.Kind.BLOCKED
                )
            }
            throw GeminiException("Gemini returned no answer.", GeminiException.Kind.BAD_RESPONSE)
        }

        val candidate = candidates.getJSONObject(0)
        val parts = candidate.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
            }
        }
        val reply = sb.toString().trim()
        if (reply.isEmpty()) {
            val finish = candidate.optString("finishReason")
            val message = when (finish) {
                "SAFETY", "BLOCKLIST", "PROHIBITED_CONTENT", "SPII" ->
                    "Gemini declined to answer this ($finish)."
                "MAX_TOKENS" -> "The answer was cut off before it started. Try a shorter question."
                else -> "Gemini returned an empty answer${if (finish.isNotBlank()) " ($finish)" else ""}."
            }
            throw GeminiException(message, GeminiException.Kind.BLOCKED)
        }
        return reply
    }

    private fun httpError(code: Int, body: String): GeminiException {
        val apiMessage = try {
            JSONObject(body).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: JSONException) {
            ""
        }
        return when {
            code == 400 && apiMessage.contains("API key", ignoreCase = true) ->
                GeminiException(
                    "Gemini rejected the API key. Check it in Settings.",
                    GeminiException.Kind.AUTH
                )
            code == 400 ->
                GeminiException(
                    "Gemini could not process the request: ${apiMessage.ifBlank { "bad request" }}",
                    GeminiException.Kind.BAD_RESPONSE
                )
            code == 401 || code == 403 ->
                GeminiException(
                    "Gemini denied access (HTTP $code). Check that your API key is valid and the Gemini API is enabled for it.",
                    GeminiException.Kind.AUTH
                )
            code == 404 ->
                GeminiException(
                    "That model was not found. Check the model name in Settings.",
                    GeminiException.Kind.NOT_FOUND
                )
            code == 429 ->
                GeminiException(
                    "Gemini rate limit or quota reached. Wait a bit and try again.",
                    GeminiException.Kind.QUOTA
                )
            code >= 500 ->
                GeminiException(
                    "The Gemini service is having trouble (HTTP $code). Try again shortly.",
                    GeminiException.Kind.SERVER
                )
            else ->
                GeminiException(
                    "Gemini error (HTTP $code)${if (apiMessage.isNotBlank()) ": $apiMessage" else ""}",
                    GeminiException.Kind.BAD_RESPONSE
                )
        }
    }
}
