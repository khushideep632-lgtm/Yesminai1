package com.yesmin.ai.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

sealed interface WhatsAppOutcome {
    /** WhatsApp was opened. The user still has to review and tap Send themselves. */
    data class Prepared(val withChat: Boolean, val hasDraft: Boolean) : WhatsAppOutcome
    data object NotInstalled : WhatsAppOutcome
    data object InvalidNumber : WhatsAppOutcome
    data class Failed(val message: String) : WhatsAppOutcome
}

/**
 * Opens WhatsApp with a message already typed in. It never sends anything: WhatsApp shows the
 * draft and the user must press Send. This app cannot and does not send messages by itself.
 */
object WhatsAppHelper {

    private val packages = listOf("com.whatsapp", "com.whatsapp.w4b")

    fun installedPackage(context: Context): String? =
        packages.firstOrNull { context.packageManager.getLaunchIntentForPackage(it) != null }

    fun isInstalled(context: Context): Boolean = installedPackage(context) != null

    /**
     * Turns user input into the digits-only international format WhatsApp expects.
     * Returns null if the number can't be made unambiguous.
     */
    fun normalizePhone(raw: String, defaultCountryCode: String): String? {
        val trimmed = raw.trim()
        val digits = trimmed.filter { it.isDigit() }
        if (digits.length < 6) return null
        val cc = defaultCountryCode.filter { it.isDigit() }
        return when {
            trimmed.startsWith("+") -> digits
            digits.startsWith("00") -> digits.drop(2)
            cc.isNotEmpty() && digits.startsWith(cc) && digits.length >= cc.length + 9 -> digits
            cc.isNotEmpty() -> cc + digits.trimStart('0')
            else -> null
        }
    }

    fun openApp(context: Context): WhatsAppOutcome {
        val pkg = installedPackage(context) ?: return WhatsAppOutcome.NotInstalled
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return WhatsAppOutcome.NotInstalled
        return start(context, intent, withChat = false, hasDraft = false)
    }

    /**
     * @param phoneRaw optional recipient number. If null/blank, WhatsApp opens its contact
     *                 picker so the user chooses who receives the message.
     */
    fun prepareMessage(
        context: Context,
        phoneRaw: String?,
        message: String,
        defaultCountryCode: String,
    ): WhatsAppOutcome {
        val pkg = installedPackage(context) ?: return WhatsAppOutcome.NotInstalled
        val text = message.trim()

        val intent: Intent
        val withChat: Boolean
        if (!phoneRaw.isNullOrBlank()) {
            val phone = normalizePhone(phoneRaw, defaultCountryCode) ?: return WhatsAppOutcome.InvalidNumber
            val uri = buildString {
                append("https://wa.me/").append(phone)
                if (text.isNotEmpty()) append("?text=").append(Uri.encode(text))
            }
            intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).setPackage(pkg)
            withChat = true
        } else {
            if (text.isEmpty()) return openApp(context)
            intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                setPackage(pkg)
            }
            withChat = false
        }
        return start(context, intent, withChat, hasDraft = text.isNotEmpty())
    }

    private fun start(
        context: Context,
        intent: Intent,
        withChat: Boolean,
        hasDraft: Boolean,
    ): WhatsAppOutcome {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            WhatsAppOutcome.Prepared(withChat, hasDraft)
        } catch (e: ActivityNotFoundException) {
            WhatsAppOutcome.Failed("WhatsApp could not be opened.")
        } catch (e: SecurityException) {
            WhatsAppOutcome.Failed("Android didn't allow opening WhatsApp.")
        }
    }

    fun describe(outcome: WhatsAppOutcome): String = when (outcome) {
        is WhatsAppOutcome.Prepared -> when {
            outcome.withChat && outcome.hasDraft ->
                "WhatsApp is open with your draft. Review it and tap Send yourself. I haven't sent anything."
            outcome.withChat ->
                "WhatsApp is open on that chat. I haven't sent anything."
            outcome.hasDraft ->
                "WhatsApp is open. Pick who should get the draft, review it and tap Send yourself. I haven't sent anything."
            else -> "Opening WhatsApp."
        }
        WhatsAppOutcome.NotInstalled -> "WhatsApp doesn't seem to be installed on this phone."
        WhatsAppOutcome.InvalidNumber ->
            "I couldn't use that number. Include the country code, like +91 98765 43210, " +
                "or set a default country code in Settings."
        is WhatsAppOutcome.Failed -> outcome.message
    }
}
