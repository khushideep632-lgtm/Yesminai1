package com.yesmin.ai.actions

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings

data class LaunchableApp(val label: String, val packageName: String)

sealed interface LaunchOutcome {
    data class Opened(val label: String) : LaunchOutcome
    data class NotFound(val query: String, val suggestions: List<String>) : LaunchOutcome
    data class Failed(val message: String) : LaunchOutcome
}

/**
 * Opens installed apps through their normal launcher intents. This uses only public Android
 * APIs; it does not and cannot bypass any system restriction. Apps that are not visible to
 * this app, disabled, or without a launcher entry simply won't be found.
 */
object AppLauncher {

    private class Alias(val names: Set<String>, val label: String, val intent: () -> Intent)

    private val aliases = listOf(
        Alias(setOf("settings", "phone settings", "android settings", "system settings"), "Settings") {
            Intent(Settings.ACTION_SETTINGS)
        },
        Alias(setOf("wifi", "wifi settings"), "Wi-Fi settings") {
            Intent(Settings.ACTION_WIFI_SETTINGS)
        },
        Alias(setOf("bluetooth", "bluetooth settings"), "Bluetooth settings") {
            Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
        },
        Alias(setOf("dialer", "phone dialer", "dial pad", "dialpad", "keypad"), "Phone dialer") {
            Intent(Intent.ACTION_DIAL)
        },
        Alias(setOf("camera"), "Camera") {
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        },
    )

    fun listLaunchableApps(context: Context): List<LaunchableApp> {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(query, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(query, 0)
        }
        return infos
            .map { LaunchableApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.packageName != context.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun open(context: Context, requestedName: String): LaunchOutcome {
        val query = normalize(requestedName)
        if (query.isEmpty()) return LaunchOutcome.NotFound(requestedName, emptyList())

        aliases.firstOrNull { query in it.names }?.let { alias ->
            return start(context, alias.intent(), alias.label)
        }

        val apps = listLaunchableApps(context)
        val match = findBestMatch(apps, query)
        if (match == null) {
            val words = query.split(' ').filter { it.length >= 3 }
            val suggestions = apps
                .filter { app -> words.any { normalize(app.label).contains(it) } }
                .take(3)
                .map { it.label }
            return LaunchOutcome.NotFound(requestedName.trim(), suggestions)
        }

        val launchIntent = context.packageManager.getLaunchIntentForPackage(match.packageName)
            ?: return LaunchOutcome.Failed("${match.label} can't be opened from here.")
        return start(context, launchIntent, match.label)
    }

    private fun findBestMatch(apps: List<LaunchableApp>, query: String): LaunchableApp? {
        val normalized = apps.map { it to normalize(it.label) }
        normalized.firstOrNull { it.second == query }?.let { return it.first }
        normalized.filter { it.second.startsWith(query) }.minByOrNull { it.second.length }
            ?.let { return it.first }
        normalized.filter { it.second.contains(query) }.minByOrNull { it.second.length }
            ?.let { return it.first }
        val words = query.split(' ').filter { it.isNotEmpty() }
        return normalized
            .filter { (_, label) -> words.isNotEmpty() && words.all { label.contains(it) } }
            .minByOrNull { it.second.length }
            ?.first
    }

    private fun start(context: Context, intent: Intent, label: String): LaunchOutcome {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            LaunchOutcome.Opened(label)
        } catch (e: ActivityNotFoundException) {
            LaunchOutcome.Failed("No app on this phone can handle \"$label\".")
        } catch (e: SecurityException) {
            LaunchOutcome.Failed("Android didn't allow opening $label.")
        }
    }

    private fun normalize(text: String): String = text
        .lowercase()
        .replace(Regex("[^\\p{L}\\p{N} ]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
}
