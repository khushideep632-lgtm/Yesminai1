package com.yesmin.ai.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/** Phone-wide actions Android lets an accessibility service trigger without reading the screen. */
enum class GlobalAction(val label: String, val code: Int, val minSdk: Int = 26) {
    BACK("Back", AccessibilityService.GLOBAL_ACTION_BACK),
    HOME("Home", AccessibilityService.GLOBAL_ACTION_HOME),
    RECENTS("Recent apps", AccessibilityService.GLOBAL_ACTION_RECENTS),
    NOTIFICATIONS("Notifications", AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS),
    QUICK_SETTINGS("Quick settings", AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS),
    LOCK_SCREEN("Lock screen", AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, minSdk = 28),
    SCREENSHOT("Screenshot", AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, minSdk = 28),
}

/**
 * Optional, user-enabled service. It stays OFF until the user turns it on in
 * Android Settings > Accessibility. By design it:
 *  - receives no accessibility events (see res/xml/accessibility_service_config.xml)
 *  - cannot read window content, text fields or passwords
 *  - cannot perform gestures (taps/swipes)
 * and only runs a global action when the app asks for one after a user request.
 */
class YesminAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty: this service never inspects what is on screen.
    }

    override fun onInterrupt() {
        // Nothing to interrupt.
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        private var instance: YesminAccessibilityService? = null

        /** True when Android has bound the service and it can act right now. */
        fun isConnected(): Boolean = instance != null

        /** True when the user has switched the service on in Android Settings. */
        fun isEnabledInSettings(context: Context): Boolean {
            val enabled = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val component = ComponentName(context, YesminAccessibilityService::class.java)
            val full = component.flattenToString()
            val short = component.flattenToShortString()
            return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
        }

        /** Returns true if Android accepted the action. */
        fun perform(action: GlobalAction): Boolean {
            if (Build.VERSION.SDK_INT < action.minSdk) return false
            val service = instance ?: return false
            return service.performGlobalAction(action.code)
        }
    }
}
