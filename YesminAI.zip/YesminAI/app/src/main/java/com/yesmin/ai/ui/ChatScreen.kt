package com.yesmin.ai.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.yesmin.ai.R
import com.yesmin.ai.model.ChatMessage
import com.yesmin.ai.model.Role
import com.yesmin.ai.voice.SpeechInput

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel, onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val listState = rememberLazyListState()

    var input by rememberSaveable { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    var partialText by remember { mutableStateOf("") }
    var showRationale by remember { mutableStateOf(false) }
    var showPermanentlyDenied by remember { mutableStateOf(false) }
    var showWhatsApp by remember { mutableStateOf(false) }

    val speech = remember {
        SpeechInput(context, object : SpeechInput.Callbacks {
            override fun onListening() {
                isListening = true
                partialText = ""
            }

            override fun onPartial(text: String) {
                partialText = text
            }

            override fun onResult(text: String) {
                partialText = ""
                vm.send(text)
            }

            override fun onError(message: String) {
                vm.showNotice(message)
            }

            override fun onEnded() {
                isListening = false
                partialText = ""
            }
        })
    }
    DisposableEffect(speech) { onDispose { speech.destroy() } }

    fun startListening() {
        vm.stopSpeaking()
        speech.start(vm.speechLanguage())
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            startListening()
        } else {
            val activity = context.findActivity()
            val canAskAgain = activity != null && ActivityCompat.shouldShowRequestPermissionRationale(
                activity, Manifest.permission.RECORD_AUDIO
            )
            if (canAskAgain) {
                vm.showNotice("Microphone permission was denied, so voice input is off.")
            } else {
                showPermanentlyDenied = true
            }
        }
    }

    fun onMicClick() {
        if (isListening) {
            speech.stop()
            return
        }
        if (!speech.isAvailable()) {
            vm.showNotice(SpeechInput.UNAVAILABLE_MESSAGE)
            return
        }
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) {
            startListening()
            return
        }
        val activity = context.findActivity()
        if (activity != null &&
            ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.RECORD_AUDIO)
        ) {
            showRationale = true
        } else {
            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(vm.notice) {
        vm.notice?.let {
            snackbarHostState.showSnackbar(it)
            vm.clearNotice()
        }
    }

    val itemCount = vm.messages.size + if (vm.isLoading) 1 else 0
    LaunchedEffect(itemCount) {
        if (itemCount > 0) listState.animateScrollToItem(itemCount - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    if (vm.speaker.isSpeaking) {
                        IconButton(onClick = { vm.stopSpeaking() }) {
                            Icon(painterResource(R.drawable.ic_volume_up), contentDescription = "Stop speaking")
                        }
                    }
                    IconButton(onClick = { showWhatsApp = true }) {
                        Icon(painterResource(R.drawable.ic_chat), contentDescription = "Prepare a WhatsApp message")
                    }
                    IconButton(onClick = { vm.clearChat() }) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear chat")
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .consumeWindowInsets(padding)
                .imePadding()
        ) {
            if (!vm.hasApiKey) MissingKeyBanner(onOpenSettings)

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(vm.messages, key = { it.id }) { MessageBubble(it) }
                if (vm.isLoading) {
                    item(key = "thinking") { ThinkingIndicator(onCancel = { vm.cancelRequest() }) }
                }
            }

            InputBar(
                text = if (isListening && partialText.isNotBlank()) partialText else input,
                isListening = isListening,
                canSend = input.isNotBlank() && !vm.isLoading && !isListening,
                onTextChange = { if (!isListening) input = it },
                onSend = {
                    vm.send(input)
                    input = ""
                },
                onMic = ::onMicClick,
            )
        }
    }

    if (showRationale) {
        AlertDialog(
            onDismissRequest = { showRationale = false },
            title = { Text("Microphone access") },
            text = {
                Text(
                    "Yesmin uses the microphone only while you are speaking after tapping the mic button. " +
                        "Audio is processed by your phone's speech recognition service. " +
                        "You can still type without this permission."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showRationale = false
                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }) { Text("Continue") }
            },
            dismissButton = { TextButton(onClick = { showRationale = false }) { Text("Not now") } },
        )
    }

    if (showPermanentlyDenied) {
        AlertDialog(
            onDismissRequest = { showPermanentlyDenied = false },
            title = { Text("Microphone is blocked") },
            text = {
                Text(
                    "Android won't show the permission prompt again. To use voice input, open the app " +
                        "settings, choose Permissions > Microphone and allow it."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showPermanentlyDenied = false
                    context.openAppDetailsSettings()
                }) { Text("Open app settings") }
            },
            dismissButton = { TextButton(onClick = { showPermanentlyDenied = false }) { Text("Cancel") } },
        )
    }

    if (showWhatsApp) {
        WhatsAppDialog(
            onDismiss = { showWhatsApp = false },
            onOpen = { phone, message -> vm.prepareWhatsApp(phone, message) },
        )
    }
}

@Composable
private fun MissingKeyBanner(onOpenSettings: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer,
            contentColor = MaterialTheme.colorScheme.onErrorContainer,
        ),
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Icon(Icons.Default.Warning, contentDescription = null)
            Text(
                "No Gemini API key yet, so AI answers are off. Phone commands still work.",
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
            )
            TextButton(onClick = onOpenSettings) { Text("Add key") }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == Role.USER
    val scheme = MaterialTheme.colorScheme
    val container = when {
        message.isError -> scheme.errorContainer
        isUser -> scheme.primaryContainer
        else -> scheme.surfaceVariant
    }
    val content = when {
        message.isError -> scheme.onErrorContainer
        isUser -> scheme.onPrimaryContainer
        else -> scheme.onSurfaceVariant
    }
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
    ) {
        Surface(
            color = container,
            contentColor = content,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 340.dp),
        ) {
            SelectionContainer {
                Text(message.text, modifier = Modifier.padding(12.dp))
            }
        }
    }
}

@Composable
private fun ThinkingIndicator(onCancel: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.padding(start = 4.dp),
    ) {
        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        Text("Thinking…", style = MaterialTheme.typography.bodyMedium)
        TextButton(onClick = onCancel) { Text("Cancel") }
    }
}

@Composable
private fun InputBar(
    text: String,
    isListening: Boolean,
    canSend: Boolean,
    onTextChange: (String) -> Unit,
    onSend: () -> Unit,
    onMic: () -> Unit,
) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text(if (isListening) "Listening…" else "Message Yesmin…") },
                maxLines = 5,
                keyboardOptions = KeyboardOptions(
                    capitalization = KeyboardCapitalization.Sentences,
                    keyboardType = KeyboardType.Text,
                ),
            )
            IconButton(onClick = onMic) {
                Icon(
                    painterResource(if (isListening) R.drawable.ic_stop else R.drawable.ic_mic),
                    contentDescription = if (isListening) "Stop listening" else "Start voice input",
                    tint = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                )
            }
            IconButton(onClick = onSend, enabled = canSend) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send")
            }
        }
    }
}

@Composable
private fun WhatsAppDialog(
    onDismiss: () -> Unit,
    onOpen: (phone: String, message: String) -> String?,
) {
    var phone by rememberSaveable { mutableStateOf("") }
    var message by rememberSaveable { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Prepare a WhatsApp message") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "This opens WhatsApp with your text filled in. I never send it: you review it and " +
                        "tap Send in WhatsApp yourself.",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it; error = null },
                    label = { Text("Phone (optional, e.g. +91 98765 43210)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                )
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it; error = null },
                    label = { Text("Message") },
                    minLines = 2,
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                )
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val problem = onOpen(phone, message)
                if (problem == null) onDismiss() else error = problem
            }) { Text("Open WhatsApp") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
