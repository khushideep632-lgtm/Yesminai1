package com.yesmin.ai.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yesmin.ai.actions.CommandResult
import com.yesmin.ai.actions.CommandRouter
import com.yesmin.ai.actions.WhatsAppHelper
import com.yesmin.ai.actions.WhatsAppOutcome
import com.yesmin.ai.ai.GeminiClient
import com.yesmin.ai.data.SettingsRepository
import com.yesmin.ai.model.ChatMessage
import com.yesmin.ai.model.Role
import com.yesmin.ai.voice.Speaker
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    val settings = SettingsRepository(application)
    val speaker = Speaker(application, settings)
    private val router = CommandRouter(application, settings)

    val messages = mutableStateListOf<ChatMessage>()

    var isLoading by mutableStateOf(false)
        private set

    /** One-shot message for a snackbar. */
    var notice by mutableStateOf<String?>(null)
        private set

    var hasApiKey by mutableStateOf(settings.apiKey().isNotBlank())
        private set

    private var nextId = 0L
    private var requestJob: Job? = null

    init {
        messages += ChatMessage(
            id = nextId++,
            role = Role.ASSISTANT,
            text = "Hi, I'm Yesmin. Ask me anything, tap the mic to talk, or say \"open YouTube\". " +
                "Type \"help\" to see what I can do."
        )
    }

    fun refreshConfig() {
        hasApiKey = settings.apiKey().isNotBlank()
    }

    fun showNotice(message: String) {
        notice = message
    }

    fun clearNotice() {
        notice = null
    }

    fun speechLanguage(): String = settings.speechLanguage

    fun stopSpeaking() = speaker.stop()

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || isLoading) return

        speaker.stop()
        messages += ChatMessage(nextId++, Role.USER, text)

        when (val command = router.tryHandle(text)) {
            is CommandResult.Reply -> {
                addAssistant(command.text)
                return
            }
            CommandResult.NotACommand -> Unit
        }

        isLoading = true
        val snapshot = messages.toList()
        requestJob = viewModelScope.launch {
            try {
                val result = GeminiClient.generate(
                    apiKey = settings.apiKey(),
                    model = settings.model,
                    systemPrompt = settings.systemPrompt,
                    temperature = settings.temperature,
                    history = snapshot,
                )
                result.fold(
                    onSuccess = { addAssistant(it) },
                    onFailure = { addAssistant(it.message ?: "Something went wrong.", isError = true) },
                )
            } finally {
                isLoading = false
            }
        }
    }

    fun cancelRequest() {
        if (!isLoading) return
        requestJob?.cancel()
        isLoading = false
        addAssistant("Request cancelled.", isError = false, speak = false)
    }

    fun clearChat() {
        requestJob?.cancel()
        isLoading = false
        speaker.stop()
        messages.clear()
        messages += ChatMessage(nextId++, Role.ASSISTANT, "Chat cleared. What would you like to do?")
    }

    /**
     * Opens WhatsApp with a draft. Returns an error text to show in the dialog, or null if
     * WhatsApp was opened. Nothing is ever sent from here.
     */
    fun prepareWhatsApp(phone: String, message: String): String? {
        if (message.isBlank() && phone.isBlank()) return "Enter a message or a phone number."
        val outcome = WhatsAppHelper.prepareMessage(
            context = getApplication<Application>(),
            phoneRaw = phone,
            message = message,
            defaultCountryCode = settings.defaultCountryCode,
        )
        val text = WhatsAppHelper.describe(outcome)
        return if (outcome is WhatsAppOutcome.Prepared) {
            addAssistant(text, speak = false)
            null
        } else {
            text
        }
    }

    fun speakTest(): String? = speaker.speak("Hello, I am Yesmin. This is how I sound.")

    private fun addAssistant(text: String, isError: Boolean = false, speak: Boolean = true) {
        messages += ChatMessage(nextId++, Role.ASSISTANT, text, isError)
        if (!isError && speak && settings.speakReplies) {
            speaker.speak(text)?.let { notice = it }
        }
    }

    override fun onCleared() {
        requestJob?.cancel()
        speaker.shutdown()
        super.onCleared()
    }
}
