package com.yesmin.ai.data

import android.content.Context
import androidx.core.content.edit
import com.yesmin.ai.BuildConfig

enum class KeySource { USER_SAVED, BUILD_TIME, NONE }

/** Thin wrapper around SharedPreferences for all user-configurable settings. */
class SettingsRepository(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("yesmin_settings", Context.MODE_PRIVATE)
    private val secure = SecureStore(context)

    var model: String
        get() = prefs.getString(KEY_MODEL, null)?.trim()?.takeIf { it.isNotEmpty() }
            ?: BuildConfig.DEFAULT_GEMINI_MODEL
        set(value) = prefs.edit { putString(KEY_MODEL, value) }

    var systemPrompt: String
        get() = prefs.getString(KEY_SYSTEM_PROMPT, null) ?: DEFAULT_SYSTEM_PROMPT
        set(value) = prefs.edit { putString(KEY_SYSTEM_PROMPT, value) }

    var temperature: Float
        get() = prefs.getFloat(KEY_TEMPERATURE, 0.7f)
        set(value) = prefs.edit { putFloat(KEY_TEMPERATURE, value) }

    var speakReplies: Boolean
        get() = prefs.getBoolean(KEY_SPEAK_REPLIES, true)
        set(value) = prefs.edit { putBoolean(KEY_SPEAK_REPLIES, value) }

    /** BCP-47 tag such as "en-US" or "hi-IN". Blank means "use the device language". */
    var speechLanguage: String
        get() = prefs.getString(KEY_SPEECH_LANGUAGE, "")?.trim().orEmpty()
        set(value) = prefs.edit { putString(KEY_SPEECH_LANGUAGE, value.trim()) }

    var speechRate: Float
        get() = prefs.getFloat(KEY_SPEECH_RATE, 1.0f)
        set(value) = prefs.edit { putFloat(KEY_SPEECH_RATE, value) }

    /** Digits only, e.g. "91". Used when a WhatsApp number has no "+" prefix. */
    var defaultCountryCode: String
        get() = prefs.getString(KEY_COUNTRY_CODE, "")?.filter { it.isDigit() }.orEmpty()
        set(value) = prefs.edit { putString(KEY_COUNTRY_CODE, value.filter { it.isDigit() }) }

    /** The key to use: the one saved in the app wins over the optional build-time key. */
    fun apiKey(): String = userApiKey().ifBlank { BuildConfig.GEMINI_API_KEY }

    fun keySource(): KeySource = when {
        userApiKey().isNotBlank() -> KeySource.USER_SAVED
        BuildConfig.GEMINI_API_KEY.isNotBlank() -> KeySource.BUILD_TIME
        else -> KeySource.NONE
    }

    private fun userApiKey(): String = secure.get(SECRET_API_KEY).orEmpty()

    /** Throws [SecureStore.SecureStoreException] if the key cannot be stored securely. */
    fun saveUserApiKey(key: String) = secure.put(SECRET_API_KEY, key.trim())

    fun clearUserApiKey() = secure.remove(SECRET_API_KEY)

    companion object {
        private const val KEY_MODEL = "model"
        private const val KEY_SYSTEM_PROMPT = "system_prompt"
        private const val KEY_TEMPERATURE = "temperature"
        private const val KEY_SPEAK_REPLIES = "speak_replies"
        private const val KEY_SPEECH_LANGUAGE = "speech_language"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_COUNTRY_CODE = "country_code"
        private const val SECRET_API_KEY = "gemini_api_key"

        const val DEFAULT_SYSTEM_PROMPT =
            "You are Yesmin, a friendly and concise AI assistant inside an Android app. " +
                "Answer clearly and honestly. You cannot control the phone yourself. " +
                "If the user wants to open an app, tell them to say or type \"open <app name>\". " +
                "If they want to send a WhatsApp message, tell them to use the WhatsApp button " +
                "in the top bar; they review and send it themselves."
    }
}
