package com.yesmin.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Wraps Android's SpeechRecognizer. Must be created and used on the main thread.
 * The microphone permission has to be granted BEFORE [start] is called.
 */
class SpeechInput(
    private val context: Context,
    private val callbacks: Callbacks,
) {
    interface Callbacks {
        fun onListening()
        fun onPartial(text: String)
        fun onResult(text: String)
        fun onError(message: String)
        fun onEnded()
    }

    private var recognizer: SpeechRecognizer? = null

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(languageTag: String) {
        if (!isAvailable()) {
            callbacks.onError(UNAVAILABLE_MESSAGE)
            return
        }
        destroy()

        val newRecognizer = try {
            SpeechRecognizer.createSpeechRecognizer(context)
        } catch (e: Exception) {
            callbacks.onError("Could not start speech recognition: ${e.message ?: "unknown error"}")
            return
        }
        newRecognizer.setRecognitionListener(listener)
        recognizer = newRecognizer

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            if (languageTag.isNotBlank()) putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
        }
        try {
            newRecognizer.startListening(intent)
        } catch (e: Exception) {
            callbacks.onError("Could not start listening: ${e.message ?: "unknown error"}")
            destroy()
            callbacks.onEnded()
        }
    }

    /** Stops listening and lets the recognizer deliver what it has heard so far. */
    fun stop() {
        recognizer?.stopListening()
    }

    fun destroy() {
        recognizer?.destroy()
        recognizer = null
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) = callbacks.onListening()
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val text = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            if (text.isNotBlank()) callbacks.onPartial(text)
        }

        override fun onResults(results: Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
                .trim()
            if (text.isNotEmpty()) callbacks.onResult(text)
            else callbacks.onError("I didn't catch that. Please try again.")
            callbacks.onEnded()
        }

        override fun onError(error: Int) {
            callbacks.onError(describeError(error))
            callbacks.onEnded()
        }
    }

    private fun describeError(code: Int): String = when (code) {
        SpeechRecognizer.ERROR_AUDIO -> "There was a problem recording audio."
        SpeechRecognizer.ERROR_CLIENT -> "Speech recognition was interrupted. Try again."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
            "Microphone permission is missing. Allow it in Settings > Permissions."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Speech recognition needs a network connection right now. Check your internet."
        SpeechRecognizer.ERROR_NO_MATCH -> "I didn't catch that. Please try again."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
            "The speech service is busy. Wait a moment and try again."
        SpeechRecognizer.ERROR_SERVER -> "The speech service reported an error. Try again."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything. Tap the mic and speak."
        SpeechRecognizer.ERROR_TOO_MANY_REQUESTS ->
            "Speech recognition is rate limited. Wait a moment and try again."
        SpeechRecognizer.ERROR_SERVER_DISCONNECTED ->
            "The speech service disconnected. Try again."
        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ->
            "The chosen speech language isn't available. Change it in Settings > Speech."
        else -> "Speech recognition failed (error $code)."
    }

    companion object {
        const val UNAVAILABLE_MESSAGE =
            "Speech recognition isn't available on this device. Install or enable a speech " +
                "service (for example the Google app) in Android Settings, then try again."
    }
}
