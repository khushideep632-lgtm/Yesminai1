package com.yesmin.ai.actions

import android.content.Context
import android.os.Build
import com.yesmin.ai.accessibility.GlobalAction
import com.yesmin.ai.accessibility.YesminAccessibilityService
import com.yesmin.ai.data.SettingsRepository

sealed interface CommandResult {
    data class Reply(val text: String) : CommandResult
    data object NotACommand : CommandResult
}

/**
 * Recognises a small set of phone commands typed or spoken by the user and runs them locally.
 * Anything else is passed on to Gemini. Commands are matched strictly (whole phrases) so normal
 * questions are not hijacked.
 */
class CommandRouter(
    context: Context,
    private val settings: SettingsRepository,
) {
    private val context = context.applicationContext

    private val accessibilityPhrases: Map<GlobalAction, Set<String>> = mapOf(
        GlobalAction.BACK to setOf("go back", "press back", "back button", "navigate back", "press the back button"),
        GlobalAction.HOME to setOf(
            "go home", "home screen", "go to home screen", "go to the home screen",
            "press home", "show home screen", "show the home screen"
        ),
        GlobalAction.RECENTS to setOf(
            "recent apps", "show recent apps", "open recent apps", "recents",
            "show recents", "open recents", "app switcher"
        ),
        GlobalAction.NOTIFICATIONS to setOf(
            "notifications", "show notifications", "open notifications",
            "pull down notifications", "open notification shade"
        ),
        GlobalAction.QUICK_SETTINGS to setOf("quick settings", "open quick settings", "show quick settings"),
        GlobalAction.LOCK_SCREEN to setOf(
            "lock screen", "lock the screen", "lock phone", "lock my phone", "lock the phone"
        ),
        GlobalAction.SCREENSHOT to setOf(
            "take a screenshot", "take screenshot", "screenshot", "capture screen"
        ),
    )

    private val whatsAppComposePatterns = listOf(
        Regex("^(?:send|compose|write|draft)\\s+(?:a\\s+)?whats\\s?app(?:\\s+message)?(?:\\s+to)?\\s*(.*)$", RegexOption.IGNORE_CASE),
        Regex("^whats\\s?app\\s+(?:message|msg|to|send)\\s*(.*)$", RegexOption.IGNORE_CASE),
        Regex("^whats\\s?app\\s+(\\+?\\d.*)$", RegexOption.IGNORE_CASE),
    )

    private val numberThenMessage = Regex(
        "^(\\+?\\d[\\d\\s\\-()]{4,}\\d)\\s*(?:saying|say|that says|that|with|:|-)?\\s*(.*)$",
        RegexOption.IGNORE_CASE
    )

    private val openAppPattern = Regex(
        "^(?:please\\s+)?(?:open|launch)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?(?:\\s+please)?$",
        RegexOption.IGNORE_CASE
    )

    fun tryHandle(input: String): CommandResult {
        val original = input.trim().trimEnd('.', '!', '?', ',')
        val lower = original.lowercase()
            .removePrefix("please ")
            .removeSuffix(" please")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (lower in HELP_PHRASES) return CommandResult.Reply(HELP_TEXT)

        // 1) Accessibility actions (require the optional service).
        accessibilityPhrases.entries.firstOrNull { lower in it.value }?.let { (action, _) ->
            return CommandResult.Reply(runAccessibilityAction(action))
        }

        // 2) WhatsApp drafts. Never sends: the user reviews and presses Send in WhatsApp.
        for (pattern in whatsAppComposePatterns) {
            val match = pattern.matchEntire(original) ?: continue
            return CommandResult.Reply(handleWhatsApp(match.groupValues[1].trim()))
        }

        // 3) Open an installed app.
        val openMatch = openAppPattern.matchEntire(original)
        if (openMatch != null) {
            val name = openMatch.groupValues[1].trim()
            if (name.equals("whatsapp", ignoreCase = true) || name.equals("whats app", ignoreCase = true)) {
                return CommandResult.Reply(WhatsAppHelper.describe(WhatsAppHelper.openApp(context)))
            }
            return when (val outcome = AppLauncher.open(context, name)) {
                is LaunchOutcome.Opened -> CommandResult.Reply("Opening ${outcome.label}.")
                is LaunchOutcome.Failed -> CommandResult.Reply(outcome.message)
                is LaunchOutcome.NotFound ->
                    // Long phrases ("open the pod bay doors") are probably not app names.
                    if (name.split(' ').size > 3) CommandResult.NotACommand
                    else CommandResult.Reply(notFoundMessage(outcome))
            }
        }

        return CommandResult.NotACommand
    }

    private fun notFoundMessage(outcome: LaunchOutcome.NotFound): String {
        val base = "I couldn't find an installed app called \"${outcome.query}\"."
        return if (outcome.suggestions.isEmpty()) base
        else "$base Did you mean: ${outcome.suggestions.joinToString(", ")}?"
    }

    private fun handleWhatsApp(rest: String): String {
        if (rest.isEmpty()) return WhatsAppHelper.describe(WhatsAppHelper.openApp(context))
        val numberMatch = numberThenMessage.matchEntire(rest)
        val outcome = if (numberMatch != null) {
            WhatsAppHelper.prepareMessage(
                context = context,
                phoneRaw = numberMatch.groupValues[1],
                message = numberMatch.groupValues[2],
                defaultCountryCode = settings.defaultCountryCode,
            )
        } else {
            WhatsAppHelper.prepareMessage(context, null, rest, settings.defaultCountryCode)
        }
        return WhatsAppHelper.describe(outcome)
    }

    private fun runAccessibilityAction(action: GlobalAction): String {
        if (Build.VERSION.SDK_INT < action.minSdk) {
            return "\"${action.label}\" needs Android 9 or newer."
        }
        if (!YesminAccessibilityService.isConnected()) {
            return if (YesminAccessibilityService.isEnabledInSettings(context)) {
                "The accessibility service is switched on but hasn't connected yet. Wait a moment and try again."
            } else {
                "That needs the optional accessibility service, which is off. " +
                    "To use it, open Settings in this app, go to Permissions, and follow the Accessibility steps."
            }
        }
        return if (YesminAccessibilityService.perform(action)) "Done: ${action.label}."
        else "Android didn't accept the \"${action.label}\" action."
    }

    private companion object {
        val HELP_PHRASES = setOf("help", "what can you do", "commands", "what can you do for me")

        const val HELP_TEXT =
            "Here's what I can do:\n" +
                "• Chat: ask me anything.\n" +
                "• Voice: tap the mic and talk.\n" +
                "• Open apps: say \"open YouTube\" or \"open Settings\".\n" +
                "• WhatsApp: say \"send WhatsApp to +91 98765 43210 saying hello\" or use the chat button " +
                "in the top bar. I only prepare the message; you press Send.\n" +
                "• With the optional accessibility service on: \"go back\", \"go home\", \"recent apps\", " +
                "\"show notifications\", \"quick settings\", \"lock screen\", \"take a screenshot\"."
    }
}
