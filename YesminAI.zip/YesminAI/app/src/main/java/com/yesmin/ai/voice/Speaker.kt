package com.yesmin.ai.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.yesmin.ai.data.SettingsRepository
import java.util.Locale

/** Wraps Android TextToSpeech. Observable [isReady] and [isSpeaking] drive the UI. */
class Speaker(
    context: Context,
    private val settings: SettingsRepository,
) : TextToSpeech.OnInitListener {

    var isReady by mutableStateOf(false)
        private set

    var initFailed by mutableStateOf(false)
        private set

    var isSpeaking by mutableStateOf(false)
        private set

    private val tts: TextToSpeech = TextToSpeech(context.applicationContext, this)

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    isSpeaking = true
                }

                override fun onDone(utteranceId: String?) {
                    isSpeaking = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    isSpeaking = false
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    isSpeaking = false
                }

                override fun onStop(utteranceId: String?, interrupted: Boolean) {
                    isSpeaking = false
                }
            })
            isReady = true
        } else {
            initFailed = true
        }
    }

    /** Speaks [text]. Returns a human-readable problem description, or null on success. */
    fun speak(text: String): String? {
        if (initFailed) return NO_ENGINE_MESSAGE
        if (!isReady) return "The voice engine is still starting. Try again in a moment."

        val tag = settings.speechLanguage
        val locale = if (tag.isBlank()) Locale.getDefault() else Locale.forLanguageTag(tag)
        val langResult = tts.setLanguage(locale)
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            return "The voice engine has no voice for ${locale.displayName}. " +
                "Install voice data in Android Settings > Text-to-speech, or change the language in Settings."
        }
        tts.setSpeechRate(settings.speechRate)

        val clean = cleanForSpeech(text).take(TextToSpeech.getMaxSpeechInputLength() - 1)
        if (clean.isBlank()) return null
        val result = tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
        return if (result == TextToSpeech.SUCCESS) null else "The voice engine could not speak that."
    }

    fun stop() {
        if (isReady) tts.stop()
        isSpeaking = false
    }

    fun shutdown() {
        tts.stop()
        tts.shutdown()
    }

    /** Drops markdown symbols so the voice doesn't read "asterisk asterisk". */
    private fun cleanForSpeech(text: String): String = text
        .replace(Regex("```[\\s\\S]*?```"), " code block omitted. ")
        .replace(Regex("\\[([^\\]]+)]\\([^)]*\\)"), "$1")
        .replace(Regex("[*_`#>~]+"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    private companion object {
        const val UTTERANCE_ID = "yesmin-utterance"
        const val NO_ENGINE_MESSAGE =
            "No text-to-speech engine is available on this device. Install one in Android " +
                "Settings > Text-to-speech to hear replies."
    }
}
