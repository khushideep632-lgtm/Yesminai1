package com.yesmin.ai.model

enum class Role { USER, ASSISTANT }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val isError: Boolean = false,
)
